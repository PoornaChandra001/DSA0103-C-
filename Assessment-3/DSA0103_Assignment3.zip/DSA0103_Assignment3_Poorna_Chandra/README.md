# DSA0103 Assignment 3 – P. Poorna Chandra

Register Number: 192472287  
Course Code: DSA0103  
Language: C++17

## Contents
- `Assignment_3_Original_Questions.pdf` – the original assignment PDF and all question statements.
- `Task01` to `Task07` – one independent runnable C++ program for each question.
- Each task folder contains `main.cpp`.

## Requirements
Install a C++ compiler such as GCC (g++). Check it with:

```bash
g++ --version
```

## Compile and run
Open a terminal in the folder of a task. For example:

```bash
cd Task01
g++ -std=c++17 -Wall -Wextra -Wpedantic main.cpp -o task
./task
```

On Windows PowerShell, run:

```powershell
g++ -std=c++17 -Wall -Wextra -Wpedantic main.cpp -o task.exe
.	ask.exe
```

Repeat with `Task02`, `Task03`, ... `Task07`.

## AddressSanitizer (optional)
If your GCC installation supports AddressSanitizer:

```bash
g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o task
./task
```

## Important notes
1. These programs are beginner-friendly working reference implementations for the main programming concepts in Q1–Q7.
2. The original PDF includes additional investigations and evidence requirements, such as compiler warnings, memory diagrams, timing measurements, sanitizer comparisons, output predictions, and GitHub commits. Those cannot be truthfully completed by simply compiling the reference programs. Perform those tests on your own computer and add your actual screenshots and measurements to the task folders.
3. The PDF asks you to predict the output of designated programs before executing them. Write your own prediction first, then compile and compare.
4. The programs are independent. Compile each `main.cpp` separately; do not compile all seven together because each contains its own `main()` function.
5. The C++ examples use C++17.

## Suggested GitHub repository
`DSA01-192472287-Assignment3`

Suggested commit sequence:
- Add Task01 program and output
- Add Task02 program and output
- ...
- Add Task07 program and output
- Add README and final evidence
