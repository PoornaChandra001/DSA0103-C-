#include <iostream>
#include <stdexcept>
#include <vector>
#include <string>
using namespace std;

class Time {
    int seconds;

public:
    explicit Time(int s = 0) : seconds(s) {}
    Time& operator++() { ++seconds; return *this; }
    Time operator++(int) {
        Time old = *this;
        ++seconds;
        return old;
    }
    bool operator==(const Time& t) const { return seconds == t.seconds; }
    bool operator<(const Time& t) const { return seconds < t.seconds; }
    void display() const {
        int h = seconds / 3600;
        int m = (seconds % 3600) / 60;
        int s = seconds % 60;
        cout << h << ':' << m << ':' << s;
    }
};

class Playlist {
    vector<string> tracks;

public:
    Playlist(initializer_list<string> list) : tracks(list) {}

    string& atIndex(int i) {
        if (i < 0 || i >= static_cast<int>(tracks.size()))
            throw out_of_range("Track index out of range");
        return tracks[static_cast<size_t>(i)];
    }
    const string& atIndex(int i) const {
        if (i < 0 || i >= static_cast<int>(tracks.size()))
            throw out_of_range("Track index out of range");
        return tracks[static_cast<size_t>(i)];
    }

    string& operator[](int i) { return atIndex(i); }
    const string& operator[](int i) const { return atIndex(i); }
    size_t size() const { return tracks.size(); }
};

int main() {
    Time t(10);
    Time a = t++;
    Time b = ++t;
    cout << "a="; a.display();
    cout << " b="; b.display();
    cout << " t="; t.display();
    cout << '\n';

    Playlist p{"Track One", "Track Two"};
    cout << p[0] << '\n';
    try {
        cout << p[-1] << '\n';
    } catch (const out_of_range& e) {
        cout << e.what() << '\n';
    }
    return 0;
}
