// Task 09: Arrays of objects
#include <iostream>
#include <string>
using namespace std;

class Employee {
private:
    int id;
    string name;
    double salary;

public:
    void setData(int i, string n, double s) {
        id = i;
        name = n;
        salary = s;
    }

    double getSalary() {
        return salary;
    }

    void display() {
        cout << "ID: " << id << "  Name: " << name << "  Salary: " << salary << endl;
    }
};

int main() {
    const int N = 4;
    Employee emp[N];      // array of 4 Employee objects

    emp[0].setData(1, "Anna",  45000);
    emp[1].setData(2, "Ravi",  52000);
    emp[2].setData(3, "Meena", 61000);
    emp[3].setData(4, "Karthik", 38000);

    cout << "--- Employee list ---" << endl;
    for (int i = 0; i < N; i++)
        emp[i].display();

    // find the highest-paid employee
    int best = 0;
    double total = 0;
    for (int i = 0; i < N; i++) {
        total += emp[i].getSalary();
        if (emp[i].getSalary() > emp[best].getSalary())
            best = i;
    }

    cout << "\nHighest paid employee:" << endl;
    emp[best].display();
    cout << "Average salary: " << total / N << endl;
    return 0;
}
