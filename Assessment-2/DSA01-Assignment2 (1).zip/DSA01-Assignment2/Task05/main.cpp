// Task 05: Function overloading (same name, different parameters)
#include <iostream>
using namespace std;

int area(int side) {                 // square
    return side * side;
}

int area(int length, int breadth) {  // rectangle
    return length * breadth;
}

double area(double radius) {         // circle
    return 3.14159 * radius * radius;
}

double area(double base, double height, char /*shape*/) {  // triangle (extra char only distinguishes this overload)
    return 0.5 * base * height;
}

int main() {
    cout << "Area of square (side 5)          = " << area(5) << endl;
    cout << "Area of rectangle (4 x 6)        = " << area(4, 6) << endl;
    cout << "Area of circle (radius 3.0)      = " << area(3.0) << endl;
    cout << "Area of triangle (base 4, ht 5)  = " << area(4.0, 5.0, 'T') << endl;
    return 0;
}
