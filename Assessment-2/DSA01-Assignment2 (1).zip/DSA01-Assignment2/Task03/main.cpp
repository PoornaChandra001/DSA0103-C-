// Task 03: Inline functions
#include <iostream>
using namespace std;

// inline asks the compiler to paste the function body at each call
// (saves function-call overhead for small functions)
inline int square(int n) {
    return n * n;
}

inline int maximum(int a, int b) {
    return (a > b) ? a : b;
}

inline double areaOfCircle(double r) {
    return 3.14159 * r * r;
}

int main() {
    cout << "square(7)          = " << square(7) << endl;
    cout << "maximum(12, 45)    = " << maximum(12, 45) << endl;
    cout << "areaOfCircle(2.5)  = " << areaOfCircle(2.5) << endl;
    return 0;
}
