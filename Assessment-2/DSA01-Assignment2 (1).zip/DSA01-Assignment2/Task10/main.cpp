// Task 10: Friend functions
#include <iostream>
using namespace std;

class Box {
private:
    double length, width, height;

public:
    Box(double l, double w, double h) {
        length = l;
        width = w;
        height = h;
    }

    // friend function: NOT a member, but allowed to read private data
    friend double volume(Box b);
    friend bool isBigger(Box a, Box b);
};

double volume(Box b) {
    return b.length * b.width * b.height;   // accessing private members
}

bool isBigger(Box a, Box b) {
    return volume(a) > volume(b);
}

int main() {
    Box b1(2, 3, 4);
    Box b2(5, 5, 1);

    cout << "Volume of b1 = " << volume(b1) << endl;
    cout << "Volume of b2 = " << volume(b2) << endl;

    if (isBigger(b1, b2))
        cout << "b1 is bigger than b2" << endl;
    else
        cout << "b2 is bigger than b1" << endl;
    return 0;
}
