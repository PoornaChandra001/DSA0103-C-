// Task 02: Return by reference
#include <iostream>
using namespace std;

int arr[5] = {10, 20, 30, 40, 50};

// Returns a reference to an element, so the caller can modify it directly
int &getElement(int index) {
    return arr[index];
}

// Returns a reference to the larger of two variables
int &larger(int &a, int &b) {
    return (a > b) ? a : b;
}

int main() {
    cout << "Original arr[2] = " << arr[2] << endl;

    getElement(2) = 99;   // function call on the left side of =
    cout << "After getElement(2) = 99, arr[2] = " << arr[2] << endl;

    int p = 15, q = 25;
    cout << "p = " << p << ", q = " << q << endl;
    larger(p, q) = 0;     // the larger variable (q) is set to 0
    cout << "After larger(p, q) = 0: p = " << p << ", q = " << q << endl;
    return 0;
}
