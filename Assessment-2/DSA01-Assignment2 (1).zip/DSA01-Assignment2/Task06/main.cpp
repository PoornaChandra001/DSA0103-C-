// Task 06: Specifying a class, member functions and access specifiers
#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:                    // only accessible inside the class
    string holder;
    double balance;

public:                     // accessible from anywhere
    void setDetails(string name, double initial) {
        holder = name;
        balance = initial;
    }

    void deposit(double amount) {
        if (amount > 0) balance += amount;
    }

    bool withdraw(double amount);   // defined outside the class below

    void display() {
        cout << "Holder: " << holder << ", Balance: " << balance << endl;
    }
};

// Member function defined outside the class using the scope resolution operator ::
bool BankAccount::withdraw(double amount) {
    if (amount > 0 && amount <= balance) {
        balance -= amount;
        return true;
    }
    return false;
}

int main() {
    BankAccount acc;
    acc.setDetails("Anna", 5000);
    acc.display();

    acc.deposit(1500);
    cout << "After depositing 1500: ";
    acc.display();

    if (acc.withdraw(2000))
        cout << "Withdrew 2000 successfully. ";
    acc.display();

    if (!acc.withdraw(10000))
        cout << "Withdrawing 10000 failed (insufficient balance)" << endl;

    // acc.balance = 1;   // ERROR if uncommented: balance is private
    return 0;
}
