// Task 07: Arrays within a class
#include <iostream>
using namespace std;

class Student {
private:
    int rollNo;
    int marks[5];     // array inside the class

public:
    void readData(int roll, const int m[]) {
        rollNo = roll;
        for (int i = 0; i < 5; i++)
            marks[i] = m[i];
    }

    int total() {
        int sum = 0;
        for (int i = 0; i < 5; i++)
            sum += marks[i];
        return sum;
    }

    double average() {
        return total() / 5.0;
    }

    int highest() {
        int h = marks[0];
        for (int i = 1; i < 5; i++)
            if (marks[i] > h) h = marks[i];
        return h;
    }

    void display() {
        cout << "Roll No: " << rollNo << endl;
        cout << "Marks  : ";
        for (int i = 0; i < 5; i++)
            cout << marks[i] << " ";
        cout << endl;
        cout << "Total  : " << total() << endl;
        cout << "Average: " << average() << endl;
        cout << "Highest: " << highest() << endl;
    }
};

int main() {
    int m[5] = {78, 85, 92, 67, 88};
    Student s;
    s.readData(101, m);
    s.display();
    return 0;
}
