// Task 08: Static data members and static member functions
#include <iostream>
using namespace std;

class Counter {
private:
    int id;
    static int count;      // shared by ALL objects of the class

public:
    Counter() {
        count++;
        id = count;
    }

    // static function: can be called without an object, can only touch static members
    static int getCount() {
        return count;
    }

    void show() {
        cout << "Object id = " << id << endl;
    }
};

// Static data member must be defined (initialised) outside the class
int Counter::count = 0;

int main() {
    cout << "Objects created so far: " << Counter::getCount() << endl;

    Counter c1;
    Counter c2;
    Counter c3;

    c1.show();
    c2.show();
    c3.show();

    cout << "Objects created so far: " << Counter::getCount() << endl;
    return 0;
}
