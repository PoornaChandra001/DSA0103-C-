# DSA01-<RegisterNumber>-Assignment2 (CO2)

- **Name:** <Your Name>
- **Register Number:** <RegisterNumber>
- **Compiler:** g++ 13.3.0 (Ubuntu)
- **Compile command:** `g++ -std=c++17 -Wall -Wextra main.cpp -o main`
- **Run:** `./main` (Windows: `main.exe`)

To run any task:
```
cd TaskNN
g++ -std=c++17 -Wall -Wextra main.cpp -o main
./main
```
Each folder has `main.cpp` and `output.txt` (the real output). Add your output screenshots to each folder too.

| Task | Topic | Result |
|------|-------|--------|
| Task01 | Function prototyping, call by value vs reference | Swap by value leaves x,y unchanged; swap by reference swaps them |
| Task02 | Return by reference | Function call used on left side of `=` modifies arr[2] and the larger variable |
| Task03 | Inline functions | square, maximum, circle area computed correctly |
| Task04 | Default arguments | Interest and greeting work with 1, 2 or 3 arguments |
| Task05 | Function overloading | One name `area()` handles square, rectangle, circle, triangle |
| Task06 | Class, member functions, access specifiers | BankAccount deposit/withdraw; private data protected |
| Task07 | Arrays within a class | Student total, average, highest from marks[5] |
| Task08 | Static data members & functions | Counter tracks 3 objects through a shared static count |
| Task09 | Arrays of objects | Employee[4] list, highest salary and average |
| Task10 | Friend functions | `volume()` and `isBigger()` read private Box data |

## Suggested git commits (one per task)
```
git init
git add Task01 && git commit -m "Task01: prototyping and call by reference"
git add Task02 && git commit -m "Task02: return by reference"
... (repeat for Task03 to Task10)
git remote add origin <your-repo-url>
git push -u origin main
```
