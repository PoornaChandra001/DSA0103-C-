// Task 04: Default arguments
#include <iostream>
using namespace std;

// Default values are given only in the declaration/definition (right-most params first)
double simpleInterest(double principal, double rate = 5.0, int years = 1) {
    return (principal * rate * years) / 100;
}

void greet(string name = "Student", string message = "Welcome to C++") {
    cout << "Hello " << name << ", " << message << "!" << endl;
}

int main() {
    cout << "simpleInterest(1000)           = " << simpleInterest(1000) << endl;
    cout << "simpleInterest(1000, 8)        = " << simpleInterest(1000, 8) << endl;
    cout << "simpleInterest(1000, 8, 3)     = " << simpleInterest(1000, 8, 3) << endl;

    greet();
    greet("Anna");
    greet("Anna", "Good luck with Assignment 2");
    return 0;
}
