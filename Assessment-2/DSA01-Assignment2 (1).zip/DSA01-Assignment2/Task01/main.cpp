// Task 01: Function prototyping and call by value vs call by reference
#include <iostream>
using namespace std;

// Function prototypes (declarations) - tell the compiler the function exists
void swapByValue(int a, int b);
void swapByReference(int &a, int &b);
int add(int a, int b);

int main() {
    int x = 10, y = 20;

    cout << "Before swapByValue:     x = " << x << ", y = " << y << endl;
    swapByValue(x, y);   // copies are swapped, originals unchanged
    cout << "After  swapByValue:     x = " << x << ", y = " << y << endl;

    swapByReference(x, y);   // originals are swapped
    cout << "After  swapByReference: x = " << x << ", y = " << y << endl;

    cout << "add(x, y) = " << add(x, y) << endl;
    return 0;
}

// Function definitions come after main
void swapByValue(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
}

void swapByReference(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

int add(int a, int b) {
    return a + b;
}
