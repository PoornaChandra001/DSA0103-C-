# Local C++17 compile and run verification

Each program was compiled with `g++ -std=c++17 -Wall -Wextra` and executed successfully in this environment.

## Task01
Compile: PASS
Run: PASS

```text
Anu (101) Pay = 76000.00
Bala (102) Pay = 42600.00
Chitra (103) Pay = 32000.00
```

## Task02
Compile: PASS
Run: PASS

```text
Person Student Staff TA
Name: Kavya, ID: 101, Programme: ECE, Department: Electronics
Person Student Fellowship: 12000
```

## Task03
Compile: PASS
Run: PASS

```text
Construction/destruction order: Vehicle Engine Car ~Car ~Engine ~Vehicle 
Student with member object: 192311001 Kavya (19) Salem-636001
```

## Task04
Compile: PASS
Run: PASS

```text
3.5
4
```

## Task05
Compile: PASS
Run: PASS

```text
Cart items:
Rice: 60
Dal: 120
Oil: 180
Discounted total: 324.00
Highest total: 480.00
```

## Task06
Compile: PASS
Run: PASS

```text
BIKE01 rate/day=100 rented=no
Two-day charge = 200
TW01 rate/day=250 rented=no
Two-day charge = 500
CAR01 rate/day=1200 rented=no
Two-day charge = 2400
EV01 rate/day=1500 rented=no
Two-day charge = 3480
Bicycle rented successfully
Return charge = 100
```
