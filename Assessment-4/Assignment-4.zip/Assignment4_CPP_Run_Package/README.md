# Assignment 4 – C++17 runnable package

This package is based on the uploaded `Assignment4_Cpp_Report_Poorna_Chandra.docx`.

## Contents
- `QUESTIONS.md` – task questions and requirements extracted from the report.
- `Task01` to `Task06` – one independent, complete C++ program per task.
- `run_all.sh` – compiles and runs all six programs on Linux/macOS with `g++`.
- `run_all.bat` – compiles and runs all six programs on Windows with MinGW `g++`.

## Requirements
- A C++ compiler that supports C++17 (`g++` recommended).
- Check installation: `g++ --version`

## Run one task
Example for Task 1:
```bash
g++ -std=c++17 -Wall -Wextra Task01/main.cpp -o task1
./task1
```
On Windows:
```bat
g++ -std=c++17 -Wall -Wextra Task01\main.cpp -o task1.exe
task1.exe
```

## Run all tasks
Linux/macOS:
```bash
chmod +x run_all.sh
./run_all.sh
```
Windows (MinGW):
```bat
run_all.bat
```

Each task is a separate executable because each has its own `main()` function. The programs use only standard C++ headers; no external libraries are needed.

## Important
The source report contains design explanations and code examples rather than a separately reproduced original assignment-question sheet. `QUESTIONS.md` therefore records the task prompts and requirements stated in the report. Check these against your faculty's original assignment PDF if exact wording is required.
