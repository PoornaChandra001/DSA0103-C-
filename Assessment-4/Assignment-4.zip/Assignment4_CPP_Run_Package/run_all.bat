@echo off
setlocal
for %%T in (Task01 Task02 Task03 Task04 Task05 Task06) do (
  echo ========== %%T: compile ==========
  g++ -std=c++17 -Wall -Wextra %%T\main.cpp -o %%T.exe
  if errorlevel 1 exit /b 1
  echo ========== %%T: run ==========
  %%T.exe
  if errorlevel 1 exit /b 1
  echo.
)
endlocal
