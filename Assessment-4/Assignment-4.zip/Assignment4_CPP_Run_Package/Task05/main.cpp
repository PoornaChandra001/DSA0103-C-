#include <iomanip>
#include <iostream>
#include <string>

class Cart {
private:
    std::string items[10];
    double prices[10]{};
    int n = 0;
    double discount = 0;

public:
    Cart& add(const std::string& item, double price) {
        if (n < 10) {
            items[n] = item;
            prices[n] = price;
            ++n;
        }
        return *this;
    }

    Cart& setDiscount(double value) {
        this->discount = value;
        return *this;
    }

    double total() const {
        double sum = 0;
        for (int i = 0; i < n; ++i) {
            sum += prices[i];
        }
        return sum * (100 - discount) / 100;
    }

    void show() const {
        for (int i = 0; i < n; ++i) {
            std::cout << items[i] << ": " << prices[i] << '\n';
        }
    }
};

class SimpleCart {
    double amount;

public:
    explicit SimpleCart(double a) : amount(a) {}
    double total() const { return amount; }
};

int main() {
    Cart cart;
    cart.add("Rice", 60).add("Dal", 120).setDiscount(10);

    Cart* pointer = &cart;
    pointer->add("Oil", 180);

    std::cout << "Cart items:\n";
    cart.show();
    std::cout << std::fixed << std::setprecision(2)
              << "Discounted total: " << pointer->total() << '\n';

    SimpleCart a(250), b(480), c(320);
    SimpleCart* carts[] = {&a, &b, &c};
    int best = 0;

    for (int i = 1; i < 3; ++i) {
        if (carts[i]->total() > carts[best]->total()) {
            best = i;
        }
    }
    std::cout << "Highest total: " << carts[best]->total() << '\n';
}
