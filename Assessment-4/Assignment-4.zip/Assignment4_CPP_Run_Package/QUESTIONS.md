# Assignment 4 – Questions and requirements from the supplied report

## Task 1 – Class Design Review
1. Diagnose the design problems in the original payroll classes (`Professor`, `LabAssistant`, and `GuestFaculty`). Consider duplicated fields and pay logic, public data, inconsistent names, unused data, magic numbers, extensibility, and the lack of a common interface.
2. Repair the design using an abstract `Staff` base class with common identity data and a pure virtual `pay()` function. Derive `Professor`, `LabAssistant`, and `GuestFaculty`, and demonstrate polymorphic processing.
3. Defend the design. Compare inheritance with one class using a type field and `switch`; discuss extensibility, storage, and time complexity.

## Task 2 – From Requirement to Hierarchy
1. Identify the relationships among `Person`, `Student`, `Staff`, `TeachingAssistant`, and `ResearchScholar`. Distinguish “is-a” inheritance from “has-a” composition, including `Address` and `Course`.
2. Explain and resolve the diamond problem when `TeachingAssistant` inherits from both `Student` and `Staff`.
3. Design the classes using virtual inheritance and suitable access specifiers.
4. Prepare an access table for public, protected, and private inheritance.
5. Predict and explain construction output with virtual inheritance and after removing `virtual`.
6. Compare the inheritance design with composition and discuss object layout and complexity.

## Task 3 – Constructors in Derived Classes and Member Classes
1. Show how a derived-class constructor passes values to base-class constructors.
2. Demonstrate member classes for `Address` and `Course` and initialize members through an initializer list.
3. Trace construction and destruction order for virtual bases, direct bases, data members, and the derived constructor body.
4. Compare virtual and non-virtual base construction in a diamond.
5. Predict the output for the supplied `Engine`, `Vehicle`, and `Car` constructor/destructor example.
6. Complete the `Student` constructor example using `Person` as a base class and `Address` as a member class.
7. Compare a value member with a dynamically allocated pointer member.

## Task 4 – Pointers to Derived Classes: Forensics
1. Locate defects involving non-virtual functions, non-virtual destructors, object slicing, and missing `override`.
2. Compile a test version with AddressSanitizer and inspect destructor messages and sanitizer output.
3. Repair the program using virtual functions, a virtual destructor, and safe ownership (for example, `std::unique_ptr<Account>`).
4. State practices that prevent these defects.
5. Predict the output for the supplied non-virtual/virtual rate and slicing example.
6. Discuss the time complexity of processing a collection of polymorphic account objects.

## Task 5 – Pointers to Objects and the `this` Pointer
1. Demonstrate four ways to access a `Cart` object: directly, through a pointer, through a reference, and through a dynamically allocated pointer.
2. Demonstrate an array of object pointers and find the cart with the highest total.
3. Compare lifetime, safety, and use cases of the four access methods.
4. Complete the `this`-pointer example using `add()`, `setDiscount()`, `total()`, and method chaining.
5. Explain why returning `Cart&` and `*this` supports chaining.
6. Compare an array of pointers with a `std::vector<Cart>` and discuss complexity and invalidation.

## Task 6 – Design Challenge: Vehicle Rental Fleet
1. Interpret the vehicle-rental requirements for bicycles, two-wheelers, cars, and electric cars.
2. Propose a reusable class hierarchy with an abstract `Vehicle` base class and suitable intermediate/derived classes.
3. Justify where registration number, daily rate, rental status, fuel/charge level, service date, seating capacity, and battery information belong.
4. Write pseudocode for renting and returning a vehicle.
5. Implement and demonstrate polymorphic rental-charge calculation, renting, and returning.
6. Extend the design with a new vehicle type without modifying the existing fleet-processing loop.
7. Compare inheritance with a single class using a type code and `switch`; discuss storage, extensibility, and complexity.

## Submission checklist from the report
- Create repository `DSA01-192472287-Assignment4`.
- Organize source files into `Task01` through `Task06`.
- Include source code, actual program output, and a short explanation for each task.
- Compile using C++17 with warnings enabled and record actual output.
- Commit work progressively and include a README.
- Replace the GitHub placeholder in the report with the actual repository URL before submission.
