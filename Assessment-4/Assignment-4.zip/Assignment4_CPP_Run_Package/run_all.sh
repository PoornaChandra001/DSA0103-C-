#!/usr/bin/env bash
set -e
for task in Task01 Task02 Task03 Task04 Task05 Task06; do
  exe="${task,,}"
  echo "========== $task: compile =========="
  g++ -std=c++17 -Wall -Wextra "$task/main.cpp" -o "$exe"
  echo "========== $task: run =========="
  "./$exe"
  echo
done
