#include <iostream>
#include <string>

class Person {
protected:
    std::string name;
    int id;
    std::string phone;

public:
    Person(const std::string& n, int i, const std::string& p)
        : name(n), id(i), phone(p) {
        std::cout << "Person ";
    }
    virtual ~Person() = default;
};

class Student : virtual public Person {
protected:
    std::string programme;
    double cgpa;

public:
    Student(const std::string& n, int i, const std::string& p,
            const std::string& prog, double c)
        : Person(n, i, p), programme(prog), cgpa(c) {
        std::cout << "Student ";
    }
};

class Staff : virtual public Person {
protected:
    std::string department;
    double salary;

public:
    Staff(const std::string& n, int i, const std::string& p,
          const std::string& dept, double s)
        : Person(n, i, p), department(dept), salary(s) {
        std::cout << "Staff ";
    }
};

class TeachingAssistant : public Student, public Staff {
public:
    TeachingAssistant(const std::string& n, int i, const std::string& p,
                      const std::string& prog, double c,
                      const std::string& dept, double s)
        : Person(n, i, p),
          Student(n, i, p, prog, c),
          Staff(n, i, p, dept, s) {
        std::cout << "TA\n";
    }

    void show() const {
        std::cout << "Name: " << name << ", ID: " << id
                  << ", Programme: " << programme
                  << ", Department: " << department << '\n';
    }
};

class ResearchScholar : public Student {
private:
    double fellowship;

public:
    ResearchScholar(const std::string& n, int i, const std::string& p,
                    const std::string& prog, double c, double f)
        : Person(n, i, p), Student(n, i, p, prog, c), fellowship(f) {}

    void showFellowship() const {
        std::cout << "Fellowship: " << fellowship << '\n';
    }
};

int main() {
    TeachingAssistant ta("Kavya", 101, "9876543210", "ECE", 8.5,
                         "Electronics", 25000);
    ta.show();

    ResearchScholar scholar("Arun", 102, "9876501234", "ECE", 9.1, 12000);
    scholar.showFellowship();
}
