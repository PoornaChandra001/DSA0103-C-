# Task A2 – Runtime Binding and Virtual Destructor

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task03
./task03
```
This program shows a non-virtual `show()` calling a virtual `total()`, followed by derived-to-base destructor order.
