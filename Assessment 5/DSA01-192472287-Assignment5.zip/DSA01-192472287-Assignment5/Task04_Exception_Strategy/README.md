# Task A4 – Exception Strategy

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task04
./task04
```
Shows custom exceptions and specific handlers.
