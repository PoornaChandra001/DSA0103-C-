#include <iostream>
#include <stdexcept>
#include <string>

class BillingError : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class ClaimError : public BillingError {
public:
    using BillingError::BillingError;
};
class UnknownPackageError : public BillingError {
public:
    using BillingError::BillingError;
};
class PatientRecordError : public BillingError {
public:
    using BillingError::BillingError;
};

double validateClaim(double amount, double cover) {
    if (amount < 0.0 || cover < 0.0)
        throw std::invalid_argument("negative charge or cover");
    if (amount > cover)
        throw ClaimError("claim exceeds policy cover");
    return amount;
}

double packageRate(const std::string& code) {
    if (code == "PKG-A") return 12000.0;
    if (code == "PKG-B") return 18000.0;
    throw UnknownPackageError("unknown package: " + code);
}

int main() {
    try {
        std::cout << "Approved: " << validateClaim(5000.0, 8000.0) << '\n';
        std::cout << "Package rate: " << packageRate("PKG-A") << '\n';
        (void)packageRate("NOT-FOUND");
    } catch (const ClaimError& e) {
        std::cout << "Claim error: " << e.what() << '\n';
    } catch (const BillingError& e) {
        std::cout << "Billing error: " << e.what() << '\n';
    } catch (const std::exception& e) {
        std::cout << "General error: " << e.what() << '\n';
    }
    return 0;
}
