# Task A3 – Payer Hierarchy

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task02
./task02
```
The insurance example is a simplified teaching policy: it applies the co-payment percentage to the eligible amount, limited by the cover limit.
