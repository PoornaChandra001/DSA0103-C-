#include <algorithm>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Bill {
public:
    virtual ~Bill() = default;
    virtual double total() const = 0;
};

class SimpleBill final : public Bill {
    double amount;
public:
    explicit SimpleBill(double value) : amount(value) {}
    double total() const override { return amount; }
};

class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& bill) const = 0;
};

class SelfPay final : public Payer {
public:
    double amountCovered(const Bill& bill) const override {
        return bill.total();
    }
};

class Insurance final : public Payer {
    double coverLimit;
    double coPaymentPercent;
public:
    Insurance(double limit, double percent)
        : coverLimit(limit), coPaymentPercent(percent) {}
    double amountCovered(const Bill& bill) const override {
        const double eligible = std::min(bill.total(), coverLimit);
        return eligible * (1.0 - coPaymentPercent / 100.0);
    }
};

class GovernmentScheme final : public Payer {
    double fixedPackageRate;
public:
    explicit GovernmentScheme(double rate) : fixedPackageRate(rate) {}
    double amountCovered(const Bill&) const override {
        return fixedPackageRate;
    }
};

class CorporateTieUp final : public Payer {
    double discountPercent;
public:
    explicit CorporateTieUp(double discount) : discountPercent(discount) {}
    double amountCovered(const Bill& bill) const override {
        return bill.total() * (1.0 - discountPercent / 100.0);
    }
};

int main() {
    SimpleBill bill(10000.0);
    std::vector<std::unique_ptr<Payer>> payers;
    payers.push_back(std::make_unique<SelfPay>());
    payers.push_back(std::make_unique<Insurance>(8000.0, 20.0));
    payers.push_back(std::make_unique<GovernmentScheme>(6500.0));
    payers.push_back(std::make_unique<CorporateTieUp>(10.0));

    for (const auto& payer : payers) {
        std::cout << "Covered amount: " << payer->amountCovered(bill) << '\n';
    }
    return 0;
}
