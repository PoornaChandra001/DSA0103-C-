# Task A5 – Stack Unwinding and RAII

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task05
./task05
```
Expected destructor sequence: `~f ~main caught 42`.
