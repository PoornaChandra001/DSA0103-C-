# Task B1 – Complete the Code (TODO 1 to TODO 3)

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task06
./task06
```
Expected totals: Ravi 1700, Meena 47500, combined 49200.
