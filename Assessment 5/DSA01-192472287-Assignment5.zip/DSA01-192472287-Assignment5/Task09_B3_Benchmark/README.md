# Task B3 – Benchmark

Compile optimized:
```bash
g++ -std=c++17 -O2 -Wall -Wextra main.cpp -o task09
./task09
```
The program benchmarks:
- virtual functions versus a type-tag-and-switch implementation;
- return-code validation versus exception-based validation at different invalid rates.

Results vary by computer. Run several times and record your own results. The benchmark uses a checksum to prevent the compiler from removing the work.
