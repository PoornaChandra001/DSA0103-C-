#include <chrono>
#include <cstddef>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

struct BaseBill {
    virtual ~BaseBill() = default;
    virtual double total() const = 0;
};

struct OPBill : BaseBill {
    double a, b;
    OPBill(double x, double y) : a(x), b(y) {}
    double total() const override { return a + b; }
};

struct IPBill : BaseBill {
    double rate;
    int days;
    IPBill(double r, int d) : rate(r), days(d) {}
    double total() const override { return rate * days; }
};

struct TaggedBill {
    int type;
    double x;
    double y;
};

volatile double resultSink = 0.0;

template <typename Function>
double measureMilliseconds(Function function) {
    const auto start = std::chrono::steady_clock::now();
    const double checksum = function();
    const auto stop = std::chrono::steady_clock::now();
    resultSink = checksum;
    return std::chrono::duration<double, std::milli>(stop - start).count();
}

void benchmarkBills(std::size_t count) {
    std::vector<OPBill> opStorage;
    std::vector<IPBill> ipStorage;
    std::vector<BaseBill*> virtualBills;
    std::vector<TaggedBill> taggedBills;
    opStorage.reserve(count / 2 + 1);
    ipStorage.reserve(count / 2 + 1);
    virtualBills.reserve(count);
    taggedBills.reserve(count);

    for (std::size_t i = 0; i < count; ++i) {
        if (i % 2 == 0) {
            opStorage.emplace_back(100.0 + (i % 17), 50.0);
            virtualBills.push_back(&opStorage.back());
            taggedBills.push_back({0, 100.0 + (i % 17), 50.0});
        } else {
            ipStorage.emplace_back(250.0, 2);
            virtualBills.push_back(&ipStorage.back());
            taggedBills.push_back({1, 250.0, 2.0});
        }
    }

    const double virtualMs = measureMilliseconds([&]() {
        double sum = 0.0;
        for (const BaseBill* bill : virtualBills) sum += bill->total();
        return sum;
    });

    const double switchMs = measureMilliseconds([&]() {
        double sum = 0.0;
        for (const TaggedBill& bill : taggedBills) {
            switch (bill.type) {
                case 0: sum += bill.x + bill.y; break;
                case 1: sum += bill.x * bill.y; break;
                default: break;
            }
        }
        return sum;
    });

    std::cout << "Bills: " << count
              << " | virtual: " << virtualMs << " ms"
              << " | switch: " << switchMs << " ms\n";
    if (virtualBills.size() != taggedBills.size()) {
        std::cerr << "Internal test setup error\n";
    }
}

bool validReturnCode(double value) {
    return value >= 0.0 && value <= 1e6;
}

void validateByException(double value) {
    if (value < 0.0) throw std::invalid_argument("negative");
    if (value > 1e6) throw std::out_of_range("too large");
}

void benchmarkValidation(int invalidPercent, std::size_t count) {
    std::vector<double> values(count, 100.0);
    const std::size_t invalidCount = count * static_cast<std::size_t>(invalidPercent) / 100;
    for (std::size_t i = 0; i < invalidCount; ++i) values[i] = -1.0;

    const double returnMs = measureMilliseconds([&]() {
        std::size_t errors = 0;
        for (double value : values) {
            if (!validReturnCode(value)) ++errors;
        }
        return static_cast<double>(errors);
    });

    const double exceptionMs = measureMilliseconds([&]() {
        std::size_t errors = 0;
        for (double value : values) {
            try {
                validateByException(value);
            } catch (const std::exception&) {
                ++errors;
            }
        }
        return static_cast<double>(errors);
    });

    std::cout << "Invalid " << invalidPercent << "% | return codes: "
              << returnMs << " ms | exceptions: " << exceptionMs << " ms\n";
}

int main() {
    std::cout << "Virtual versus switch benchmark (optimized build recommended)\n";
    benchmarkBills(1000);
    benchmarkBills(1000000);
    benchmarkBills(10000000);

    std::cout << "\nReturn codes versus exceptions (1,000,000 validations)\n";
    benchmarkValidation(0, 1000000);
    benchmarkValidation(1, 1000000);
    benchmarkValidation(50, 1000000);
    return 0;
}
