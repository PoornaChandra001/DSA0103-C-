#!/usr/bin/env bash
set -e
mkdir -p output
for source in Task*/main.cpp; do
  name=$(basename "$(dirname "$source")")
  echo "Building $name"
  g++ -std=c++17 -Wall -Wextra "$source" -o "output/$name"
done
echo "All task programs compiled successfully."
