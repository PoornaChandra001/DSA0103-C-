# Task B2 – Complete the Code (TODO 1 and TODO 2)

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task07
./task07
```
The program validates the claim, logs ClaimError and rethrows the same exception.
