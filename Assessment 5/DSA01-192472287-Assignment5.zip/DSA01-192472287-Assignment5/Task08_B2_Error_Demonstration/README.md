# Task B2 – Error Conditions, Logging and Rethrowing

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task08
./task08
```
Expected output:
`ok done caught negative [log too large] caught too large`
