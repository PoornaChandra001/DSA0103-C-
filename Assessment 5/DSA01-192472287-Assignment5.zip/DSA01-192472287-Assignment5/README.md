# DSA0103 – Assignment 5: Reliable Software with Runtime Polymorphism and Exceptions

**Name:** P.Poorna Chandra  
**Register Number:** 192472287  
**Course Code:** DSA0103  
**Compiler:** g++ (C++17)

This project contains beginner-friendly C++ implementations and demonstrations based on the questions in Assignment 5. Each task is in its own folder.

## Requirements
- A C++ compiler that supports C++17 (for example, GCC 9 or later).
- Terminal / Command Prompt.

Check the compiler:
```bash
g++ --version
```

## Compile and run one program
Open a terminal in the project folder, then:
```bash
g++ -std=c++17 -Wall -Wextra Task01_Bill_Hierarchy/main.cpp -o task01
./task01
```
On Windows, run `task01.exe` instead of `./task01`.

## Compile all programs
On Linux/macOS with g++:
```bash
chmod +x build_all.sh
./build_all.sh
```
The script creates an `output` folder containing executable programs. On Windows, compile each `.cpp` file using the command shown in that task's README or use:
```powershell
g++ -std=c++17 -Wall -Wextra Task01_Bill_Hierarchy/main.cpp -o task01.exe
```

## Task folders
1. `Task01_Bill_Hierarchy` – abstract Bill hierarchy, derived bill types, runtime polymorphism, daily total.
2. `Task02_Payer_Hierarchy` – abstract Payer interface, self-pay, insurance and government scheme.
3. `Task03_Runtime_Binding` – virtual dispatch and virtual destructor demonstration.
4. `Task04_Exception_Strategy` – validation, custom exceptions and error handling.
5. `Task05_Stack_Unwinding` – RAII and destructor order during exception propagation.
6. `Task06_B1_Complete_Code` – completed TODO 1–3 program from Part B1.
7. `Task07_B2_Complete_Code` – completed TODO 1–2 claim approval program from Part B2.
8. `Task08_B2_Error_Demonstration` – negative values, out-of-range values, logging and rethrowing.
9. `Task09_B3_Benchmark` – virtual dispatch versus switch; return-code versus exception test.
10. `Task10_B4_Extension` – new bill type and new payer extension.

## Important notes
- The assignment asks students to predict some outputs before executing the programs. Try writing your prediction first, then run the program and compare.
- Benchmark timings depend on the computer, operating system, compiler and load. The benchmark program prints measured results; do not copy timings from another computer.
- AddressSanitizer support depends on the installed compiler. Example:
  ```bash
  g++ -std=c++17 -Wall -Wextra -fsanitize=address -fno-omit-frame-pointer Task06_B1_Complete_Code/main.cpp -o b1_asan
  ./b1_asan
  ```
- The PDF asks for a GitHub repository, progressive commits, input/output evidence, screenshots and a README. Add your own GitHub URL and screenshots after running the programs. This ZIP does not claim that GitHub submission or local execution screenshots have already been completed.
