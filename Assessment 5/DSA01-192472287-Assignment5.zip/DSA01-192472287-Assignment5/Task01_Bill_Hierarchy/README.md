# Task A1 – Polymorphic Bill Hierarchy

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task01
./task01
```
Demonstrates an abstract base class, pure virtual functions, derived bill types and processing through `Bill*`.
