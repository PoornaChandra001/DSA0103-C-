#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Bill {
protected:
    std::string patient;
public:
    explicit Bill(std::string name) : patient(std::move(name)) {}
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const = 0;

    void print() const {
        std::cout << type() << " " << patient << ": " << total() << '\n';
    }
};

class OutPatientBill final : public Bill {
    double consultation;
    double tests;
public:
    OutPatientBill(const std::string& p, double c, double t)
        : Bill(p), consultation(c), tests(t) {}
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};

class InPatientBill final : public Bill {
    int days;
    double perDay;
    double proceduresAndMedicines;
public:
    InPatientBill(const std::string& p, int d, double rate, double extra)
        : Bill(p), days(d), perDay(rate), proceduresAndMedicines(extra) {}
    double total() const override {
        return days * perDay + proceduresAndMedicines;
    }
    std::string type() const override { return "IP"; }
};

class DayCareBill final : public Bill {
    double packagePrice;
public:
    DayCareBill(const std::string& p, double price)
        : Bill(p), packagePrice(price) {}
    double total() const override { return packagePrice; }
    std::string type() const override { return "DayCare"; }
};

class EmergencyBill final : public Bill {
    double baseCharge;
    double timeCharge;
public:
    EmergencyBill(const std::string& p, double base, double time)
        : Bill(p), baseCharge(base), timeCharge(time) {}
    double total() const override { return baseCharge + timeCharge; }
    std::string type() const override { return "Emergency"; }
};

int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatientBill>("Ravi", 500, 1200));
    bills.push_back(std::make_unique<InPatientBill>("Meena", 3, 2500, 40000));
    bills.push_back(std::make_unique<DayCareBill>("Arun", 18000));
    bills.push_back(std::make_unique<EmergencyBill>("Sara", 2000, 750));

    double dayTotal = 0.0;
    for (const auto& bill : bills) {
        bill->print();
        dayTotal += bill->total();
    }
    std::cout << "Day total: " << dayTotal << '\n';
    return 0;
}
