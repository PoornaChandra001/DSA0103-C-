# Task B4 – Add a New Bill Type and Payer

Compile:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o task10
./task10
```
Adds a MaternityBill and a CorporatePayer without changing the existing bill or payer implementations.
