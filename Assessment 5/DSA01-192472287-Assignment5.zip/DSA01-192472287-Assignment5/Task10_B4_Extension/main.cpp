#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Bill {
public:
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const = 0;
};

class OutPatientBill : public Bill {
    double consultation, tests;
public:
    OutPatientBill(double c, double t) : consultation(c), tests(t) {}
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OutPatient"; }
};

class MaternityBill final : public Bill {
    double deliveryPackage;
    double additionalCare;
public:
    MaternityBill(double package, double care)
        : deliveryPackage(package), additionalCare(care) {}
    double total() const override { return deliveryPackage + additionalCare; }
    std::string type() const override { return "Maternity"; }
};

class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& bill) const = 0;
};

class SelfPay : public Payer {
public:
    double amountCovered(const Bill& bill) const override {
        return bill.total();
    }
};

class CorporatePayer final : public Payer {
    double coveragePercent;
public:
    explicit CorporatePayer(double percent) : coveragePercent(percent) {}
    double amountCovered(const Bill& bill) const override {
        return bill.total() * coveragePercent / 100.0;
    }
};

int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatientBill>(500.0, 1200.0));
    bills.push_back(std::make_unique<MaternityBill>(45000.0, 5000.0));

    SelfPay self;
    CorporatePayer corporate(80.0);

    for (const auto& bill : bills) {
        std::cout << bill->type() << " total: " << bill->total()
                  << " | self-pay covers: " << self.amountCovered(*bill)
                  << " | corporate covers: " << corporate.amountCovered(*bill)
                  << '\n';
    }
    return 0;
}
